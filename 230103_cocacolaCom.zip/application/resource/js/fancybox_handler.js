Fancybox.bind("[data-fancybox]", {

})