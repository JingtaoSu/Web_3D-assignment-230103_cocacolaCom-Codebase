<?php
echo '{"mainText":
    {
        "title": "Coca Cola Company",
        "subTitle": "Founded by Dr John S Pemberton",
        "mainBody": "The Coca Cola Company is the worlds leading manufacturer, marketer and distributor of non-alcoholic beverage concentrates and syrups, and produces nearly 400 brands."
    },
    "prodMainText": [
    {
        "title": "Coca Cola",
        "subTitle": "New York Harbour, 1886",
        "mainBody": "It was 1886, John Pemberton, an Atlanta pharmacist, was inspired by simple curiosity. One afternoon, he stirred up a fragrant, caramel-coloured liquid and, when it was done, the mixture was combined with carbonated water and sampled by customers who all agreed - this new drink was something special!"
    },
    {
        "title": "Schweppes",
        "subTitle": "Geneva, 1843",
        "mainBody": "Schweppe founded the Schweppes Company in Geneva in 1783 to sell carbonated water. In 1792, he moved to London to develop the business there. In 1843, Schweppes commercialised Malvern Water at the Holywell Spring in the Malvern Hills, which was to become a favourite of the British Royal Family until parent company Coca-Cola closed the historic plant in 2010 to local outcry."
    },
    {
        "title": "Fanta",
        "subTitle": "Deutschland, WWII",
        "mainBody": "During the Second World War, the US established a trade embargo against Nazi Germany, making the export of Coca-Cola syrup difficult. To circumvent this, Max Keith, the head of Coca-Cola Deutschland (Coca-Cola GmbH), decided to create a new product for the German market, using only ingredients available in Germany at the time, including sugar beet, whey (a cheese byproduct), and apple pomace—the leftovers of leftovers, as Keith later recalled"
    }],
    "prodParameters":[{
        "energy": "<h4>Energy</h4><h6>180kj / 42kcal per 100 ml</h6>",
        "nutrition": "<h4>Nutrition</h4><h6>Fat:                  0g</h6><h6>Carbohydrate:        10.6g</h6><h6>Protein:              0g</h6><h6>Salt:                 0g</h6>"
    },
    {
        "energy": "<h4>Energy</h4><h6>89kj / 21kcal per 100 ml</h6>",
        "nutrition": "<h4>Nutrition</h4><h6>Fat:                  0g</h6><h6>Carbohydrate:         4.9g</h6><h6>Protein:              0g</h6><h6>Salt:                 0g</h6>"
    },
    {
        "energy": "<h4>Energy</h4><h6>81kj / 19kcal per 100 ml</h6>",
        "nutrition": "<h4>Nutrition</h4><h6>Fat:                  0g</h6><h6>Carbohydrate:         4.6g</h6><h6>Protein:              0g</h6><h6>Salt:                 0g</h6>"
    }],
    "designers":[{
        "name": "John Pemberton",
        "comment": "<p>John Stith Pemberton (July 8, 1831 to August 16, 1888) was an American pharmacist and Confederate States Army veteran who is best known as the inventor of Coca-Cola. In May 1886, he developed an early version of a beverage that would later become Coca-Cola, but sold his rights to the drink shortly before his death in 1888.</p>"
    },
    {
        "name": "Johann Jacob Schweppe",
        "comment": "<p>Johann Jacob Schweppe (16 March, 1740 to 18 November, 1821) was a German-Swiss watchmaker and amateur scientist who developed the first practical process to manufacture bottled carbonated mineral water, based on a process discovered by Joseph Priestley in 1767.[1] His company, Schweppes, regards Priestley as “the father of our industry”</p>"
    },
    {
        "name": "Max Keith",
        "comment": "<p>Keith began working at the German subsidiary of Coca-Cola in 1933, at the age of 30. Between then and 1939, the sales of Coca-Cola in Germany (led by American Ray Rivington Powers) rose from 100,000 cases in 1933 to over 4 million cases just before the outbreak of the Second World War. Following Powers death in 1938, Keith took over the subsidiary.</p>"
    }]
}';
?>