<?php
// display error message
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// import external code/text/markup
require 'application/mvc.php';

// this file is to initiate the whole application
// by loading mvc.php
?>